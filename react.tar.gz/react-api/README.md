# react-api

This repository contains all the source code for the React-based MongoDB HTTPs API intergration.

## Getting Started

## Install

In the project directory, you can run the script below to install project dependency:

```
npm install
```

Then run the project using

```
npm start
```
